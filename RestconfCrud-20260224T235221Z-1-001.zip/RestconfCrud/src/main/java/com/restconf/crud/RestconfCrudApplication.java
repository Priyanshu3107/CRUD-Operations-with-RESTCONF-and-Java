package com.restconf.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestconfCrudApplication {
    public static void main(String[] args) {
        SpringApplication.run(RestconfCrudApplication.class, args);
    }
}
