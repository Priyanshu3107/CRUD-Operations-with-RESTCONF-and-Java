package com.restconf.crud.authentication;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final JdbcTemplate jdbcTemplate;

    public AuthService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // LOGIN METHOD
    public String login(String username, String password) {

        String sql = "SELECT role FROM users WHERE username=? AND password=?";

        try {
            // Fetch role from database
            String role = jdbcTemplate.queryForObject(
                    sql,
                    new Object[]{username, password},
                    String.class
            );

            return role;   // return only role (ADMIN or USER)

        } catch (Exception e) {
            return null;   // return null if login fails
        }
    }

    // REGISTER METHOD
    public String register(User user) {

        String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";

        try {
            jdbcTemplate.update(sql,
                    user.getUsername(),
                    user.getPassword(),
                    user.getRole());

            return "User Registered Successfully";

        } catch (Exception e) {
            return "User Already Exists or Error Occurred";
        }
    }
}
