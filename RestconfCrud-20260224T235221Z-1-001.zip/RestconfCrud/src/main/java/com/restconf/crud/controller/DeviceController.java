package com.restconf.crud.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.restconf.crud.model.Device;
import com.restconf.crud.service.RestconfService;

import java.util.List;

@RestController
@RequestMapping("/restconf/device")
public class DeviceController {

    private final RestconfService service;

    public DeviceController(RestconfService service) {
        this.service = service;
    }

    // CREATE (Admin Only)
    @PostMapping("/admin")
    public Device create(@RequestBody Device device,
                         @RequestHeader("Role") String role) {

        if (!role.equalsIgnoreCase("ADMIN")) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Only Admin Can Create Devices"
            );
        }

        return service.create(device);
    }

    // READ (Both Admin & User)
    @GetMapping("/{id}")
    public Device read(@PathVariable int id) {
        return service.read(id);
    }

    // GET ALL (Both Admin & User)
    @GetMapping("/info")
    public List<Device> getAllDevices() {
        return service.readAll();
    }

    // UPDATE (Admin Only)
    @PutMapping("/{id}")
    public Device update(@PathVariable int id,
                         @RequestBody Device device,
                         @RequestHeader("Role") String role) {

        if (!role.equalsIgnoreCase("ADMIN")) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Only Admin Can Update Devices"
            );
        }

        return service.update(id, device);
    }

    // DELETE (Admin Only)
    @DeleteMapping("/{id}")
    public String delete(@PathVariable int id,
                         @RequestHeader("Role") String role) {

        if (!role.equalsIgnoreCase("ADMIN")) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Only Admin Can Delete Devices"
            );
        }

        return service.delete(id);
    }
}
