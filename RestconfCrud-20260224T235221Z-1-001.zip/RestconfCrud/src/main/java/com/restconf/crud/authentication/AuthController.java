package com.restconf.crud.authentication;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    // Register API
    @PostMapping("/register")
    public String register(@RequestBody User user) {
        return authService.register(user);
    }

    // Login API
    @PostMapping("/login")
    public String login(@RequestBody User user) {

        String role = authService.login(user.getUsername(), user.getPassword());

        if (role == null) {
            return "Invalid Username or Password";
        }

        return "Login Successful! Your Role: " + role;
    }

}
