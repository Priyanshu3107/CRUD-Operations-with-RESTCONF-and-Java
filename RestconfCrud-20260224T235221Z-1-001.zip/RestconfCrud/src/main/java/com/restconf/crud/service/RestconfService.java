package com.restconf.crud.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.restconf.crud.model.Device;

@Service
public class RestconfService {

    private final JdbcTemplate jdbcTemplate;

    // Constructor Injection
    public RestconfService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // CREATE DEVICE
    public Device create(Device device) {

        String sql = "INSERT INTO device (id, name, ip) VALUES (?, ?, ?)";

        jdbcTemplate.update(sql,
                device.getId(),
                device.getName(),
                device.getIp());

        return device;
    }

    // READ ONE DEVICE
    public Device read(int id) {

        String sql = "SELECT * FROM device WHERE id=?";

        return jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (rs, rowNum) ->
                        new Device(
                                rs.getInt("id"),
                                rs.getString("name"),
                                rs.getString("ip")
                        )
        );
    }

    // READ ALL DEVICES
    public List<Device> readAll() {

        String sql = "SELECT * FROM device";

        return jdbcTemplate.query(
                sql,
                (rs, rowNum) ->
                        new Device(
                                rs.getInt("id"),
                                rs.getString("name"),
                                rs.getString("ip")
                        )
        );
    }

    // UPDATE DEVICE
    public Device update(int id, Device device) {

        String sql = "UPDATE device SET name=?, ip=? WHERE id=?";

        jdbcTemplate.update(sql,
                device.getName(),
                device.getIp(),
                id);

        return device;
    }

    // DELETE DEVICE
    public String delete(int id) {

        String sql = "DELETE FROM device WHERE id=?";

        jdbcTemplate.update(sql, id);

        return "Device Deleted Successfully for ID " + id;
    }
}
